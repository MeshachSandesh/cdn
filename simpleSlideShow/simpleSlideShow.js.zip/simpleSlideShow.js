// const slideWrapper = document.getElementById("simpleSlideShow");
const slideWrapper = document.getElementById("slideWrapperLeg");
const leftArrow = document.getElementById("arrow-left");
const rightArrow = document.getElementById("arrow-right");
const slides = document.querySelectorAll(".slideitem");

slideWrapper.style.transition = "transform 0.5s ease";

let currentIndex = 0;
const totalSlides = slides.length;

function showSlide(index, direction = "next") {
  // how much to move each time
  const step = 100;

  // read current translateX
  const style = window.getComputedStyle(slideWrapper);
  const matrix = new DOMMatrixReadOnly(style.transform);
  const currentX = matrix.m41; // current translateX in px

  // container width, so we can convert px to %
  const wrapperWidth = slideWrapper.offsetWidth;
  const currentPercent = (currentX / wrapperWidth) * 100;

  // decide step direction
  const move = direction === "next" ? -step : step;

  // apply new transform
  const newPercent = currentPercent + move;
  slideWrapper.style.transform = `translateX(${newPercent}%)`;
}

const manageShowHideNav = (currentIndex) => {
  // Handle left arrow - hide on first slide
  if (currentIndex === 0) {
    leftArrow.style.visibility = "hidden";
  } else {
    leftArrow.style.visibility = "visible";
  }

  // Handle right arrow - hide on last slide
  if (currentIndex + 1 === totalSlides) {
    rightArrow.style.visibility = "hidden";
  } else {
    rightArrow.style.visibility = "visible";
  }
};

function nextSlide() {
  currentIndex = currentIndex + 1;
  if (currentIndex >= totalSlides) {
    currentIndex = 0;
  }
  console.log(
    "nextSlide - currentIndex:",
    currentIndex,
    "totalSlides:",
    totalSlides
  );
  showSlide(currentIndex);
  manageShowHideNav(currentIndex);
}
function prevSlide() {
  currentIndex = currentIndex - 1;
  if (currentIndex < 0) {
    currentIndex = totalSlides - 1;
  }
  console.log(
    "prevSlide - currentIndex:",
    currentIndex,
    "totalSlides:",
    totalSlides
  );
  showSlide(currentIndex, "prev");
  manageShowHideNav(currentIndex);
}

manageShowHideNav(currentIndex);
leftArrow.addEventListener("click", prevSlide);
rightArrow.addEventListener("click", nextSlide);
